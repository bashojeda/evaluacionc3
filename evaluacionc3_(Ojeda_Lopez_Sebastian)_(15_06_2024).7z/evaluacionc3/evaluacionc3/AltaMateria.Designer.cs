﻿namespace evaluacionc3
{
    partial class AltaMateria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNombreMateria = new System.Windows.Forms.TextBox();
            this.labelNombreMateria = new System.Windows.Forms.Label();
            this.labelAltaMateria = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxNombreMateria
            // 
            this.textBoxNombreMateria.Location = new System.Drawing.Point(121, 84);
            this.textBoxNombreMateria.Name = "textBoxNombreMateria";
            this.textBoxNombreMateria.Size = new System.Drawing.Size(70, 20);
            this.textBoxNombreMateria.TabIndex = 31;
            // 
            // labelNombreMateria
            // 
            this.labelNombreMateria.AutoSize = true;
            this.labelNombreMateria.Location = new System.Drawing.Point(29, 88);
            this.labelNombreMateria.Name = "labelNombreMateria";
            this.labelNombreMateria.Size = new System.Drawing.Size(44, 13);
            this.labelNombreMateria.TabIndex = 29;
            this.labelNombreMateria.Text = "Nombre";
            // 
            // labelAltaMateria
            // 
            this.labelAltaMateria.AutoSize = true;
            this.labelAltaMateria.Location = new System.Drawing.Point(29, 30);
            this.labelAltaMateria.Name = "labelAltaMateria";
            this.labelAltaMateria.Size = new System.Drawing.Size(63, 13);
            this.labelAltaMateria.TabIndex = 27;
            this.labelAltaMateria.Text = "Alta Materia";
            // 
            // AltaMateria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 263);
            this.Controls.Add(this.textBoxNombreMateria);
            this.Controls.Add(this.labelNombreMateria);
            this.Controls.Add(this.labelAltaMateria);
            this.Name = "AltaMateria";
            this.Text = "Materia";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNombreMateria;
        private System.Windows.Forms.Label labelNombreMateria;
        private System.Windows.Forms.Label labelAltaMateria;
    }
}