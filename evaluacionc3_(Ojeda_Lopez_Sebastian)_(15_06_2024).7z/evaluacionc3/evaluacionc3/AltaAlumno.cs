﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace evaluacionc3
{
    public partial class AltaAlumno : Form
    {
        DBAccess dbAccess = new DBAccess();
        public AltaAlumno()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre = textBoxNombreAlumno.Text;
            string ap_Paterno = textBoxAp_Paterno_Al.Text;
            string ap_Materno = textBoxAp_Materno_Al.Text;
            string matricula = textBoxMatricula.Text;
            string fecha = textBoxFecha.Text;
            string email = textBoxNombreAlumno.Text;
            string tel = textBoxTel.Text;

            if (nombre.Equals(""))
            {
                MessageBox.Show("Favor ingresa nombre");
            }
            else if (ap_Paterno.Equals(""))
            {
                MessageBox.Show("Favor ingresa Apellido Paterno");
            }
            else if (ap_Materno.Equals(""))
            {
                MessageBox.Show("Favor ingresa Apellido Materno");
            }
            else if (matricula.Equals(""))
            {
                MessageBox.Show("Favor ingresa Matricula");
            }
            else if (fecha.Equals(""))
            {
                MessageBox.Show("Favor ingresa Fecha");
            }
            else if (email.Equals(""))
            {
                MessageBox.Show("Favor ingresa Email");
            }
            else if (tel.Equals(""))
            {
                MessageBox.Show("Favor ingresa Telefono");
            }
            else
            {
                SqlCommand insertCommand = new SqlCommand("insert into tb_alumno(nombre,ap_paterno,ap_materno,matricula_alumno,fecha_ingreso,email,telefono) values(@nombre,@ap_Paterno,@ap_Materno,@matricula,@fecha,@email,@tel)");

                insertCommand.Parameters.AddWithValue("@nombre", nombre);
                insertCommand.Parameters.AddWithValue("@ap_Paterno", ap_Paterno);
                insertCommand.Parameters.AddWithValue("@ap_Materno", ap_Materno);
                insertCommand.Parameters.AddWithValue("@matricula", matricula);
                insertCommand.Parameters.AddWithValue("@fecha", fecha);
                insertCommand.Parameters.AddWithValue("@email", email);
                insertCommand.Parameters.AddWithValue("@tel", tel);

                int row = dbAccess.executeQuery(insertCommand);

                if (row == 1)
                {
                    MessageBox.Show("Creado exitosamente");
                }
            }

        }
    }
}
