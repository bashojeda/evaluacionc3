﻿namespace evaluacionc3
{
    partial class AltaCalificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxObservacion = new System.Windows.Forms.TextBox();
            this.textBoxAltaCalificacion = new System.Windows.Forms.TextBox();
            this.textBoxAltaMateria = new System.Windows.Forms.TextBox();
            this.textBoxAltaAlumno = new System.Windows.Forms.TextBox();
            this.textBoxAltaMaestro = new System.Windows.Forms.TextBox();
            this.buttonAceptar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelCalificacion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxObservacion
            // 
            this.textBoxObservacion.Location = new System.Drawing.Point(130, 213);
            this.textBoxObservacion.Name = "textBoxObservacion";
            this.textBoxObservacion.Size = new System.Drawing.Size(129, 20);
            this.textBoxObservacion.TabIndex = 29;
            // 
            // textBoxAltaCalificacion
            // 
            this.textBoxAltaCalificacion.Location = new System.Drawing.Point(130, 181);
            this.textBoxAltaCalificacion.Name = "textBoxAltaCalificacion";
            this.textBoxAltaCalificacion.Size = new System.Drawing.Size(129, 20);
            this.textBoxAltaCalificacion.TabIndex = 28;
            // 
            // textBoxAltaMateria
            // 
            this.textBoxAltaMateria.Location = new System.Drawing.Point(130, 145);
            this.textBoxAltaMateria.Name = "textBoxAltaMateria";
            this.textBoxAltaMateria.Size = new System.Drawing.Size(129, 20);
            this.textBoxAltaMateria.TabIndex = 27;
            // 
            // textBoxAltaAlumno
            // 
            this.textBoxAltaAlumno.Location = new System.Drawing.Point(130, 114);
            this.textBoxAltaAlumno.Name = "textBoxAltaAlumno";
            this.textBoxAltaAlumno.Size = new System.Drawing.Size(129, 20);
            this.textBoxAltaAlumno.TabIndex = 26;
            // 
            // textBoxAltaMaestro
            // 
            this.textBoxAltaMaestro.Location = new System.Drawing.Point(130, 88);
            this.textBoxAltaMaestro.Name = "textBoxAltaMaestro";
            this.textBoxAltaMaestro.Size = new System.Drawing.Size(129, 20);
            this.textBoxAltaMaestro.TabIndex = 25;
            // 
            // buttonAceptar
            // 
            this.buttonAceptar.Location = new System.Drawing.Point(41, 257);
            this.buttonAceptar.Name = "buttonAceptar";
            this.buttonAceptar.Size = new System.Drawing.Size(75, 23);
            this.buttonAceptar.TabIndex = 24;
            this.buttonAceptar.Text = "Alta";
            this.buttonAceptar.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(38, 213);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Observaciones";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Calificacion";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Materia";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Alumno";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Maestro";
            // 
            // labelCalificacion
            // 
            this.labelCalificacion.AutoSize = true;
            this.labelCalificacion.Location = new System.Drawing.Point(34, 46);
            this.labelCalificacion.Name = "labelCalificacion";
            this.labelCalificacion.Size = new System.Drawing.Size(82, 13);
            this.labelCalificacion.TabIndex = 16;
            this.labelCalificacion.Text = "Alta Calificacion";
            // 
            // AltaCalificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 344);
            this.Controls.Add(this.textBoxObservacion);
            this.Controls.Add(this.textBoxAltaCalificacion);
            this.Controls.Add(this.textBoxAltaMateria);
            this.Controls.Add(this.textBoxAltaAlumno);
            this.Controls.Add(this.textBoxAltaMaestro);
            this.Controls.Add(this.buttonAceptar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelCalificacion);
            this.Name = "AltaCalificacion";
            this.Text = "Calificacion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxObservacion;
        private System.Windows.Forms.TextBox textBoxAltaCalificacion;
        private System.Windows.Forms.TextBox textBoxAltaMateria;
        private System.Windows.Forms.TextBox textBoxAltaAlumno;
        private System.Windows.Forms.TextBox textBoxAltaMaestro;
        private System.Windows.Forms.Button buttonAceptar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelCalificacion;
    }
}